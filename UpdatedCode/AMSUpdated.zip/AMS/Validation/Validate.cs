﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Validation
{
    public class Validate
    {
       
    }
}
